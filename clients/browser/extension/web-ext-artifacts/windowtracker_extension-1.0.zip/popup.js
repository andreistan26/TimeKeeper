let track_button = document.getElementById("track_button");

//var is_tracking = false;
//track_button.addEventListener("click", async (value) => {
//    is_tracking = !is_tracking;
    // start client
//
//});